'use strict';

angular.module('ace', ['ngCookies', 'ngResource', 'ngRoute', 'ui.bootstrap', 'ui.route', 'ace.system']);
angular.module('ace.system', []);