'use strict';

angular.element(document).ready(function() {

    //Then init the app
    angular.bootstrap(document, ['ace']);
});